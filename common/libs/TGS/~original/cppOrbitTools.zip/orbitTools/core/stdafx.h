//
// stdafx.h
//
// Copyright (c) 2003-2013 Michael F. Henry
//
#pragma once

#include <stdio.h>
#include <tchar.h>
#include <math.h>
#include <time.h>
#include <assert.h>

#include <string>
#include <map>

using namespace std;