//
// stdafx.h
//
#pragma once

#include <stdio.h>
#include <tchar.h>
#include <math.h>
#include <time.h>

#include <string>
#include <map>
#include <vector>
#include <algorithm>
#include <assert.h>

using namespace std;