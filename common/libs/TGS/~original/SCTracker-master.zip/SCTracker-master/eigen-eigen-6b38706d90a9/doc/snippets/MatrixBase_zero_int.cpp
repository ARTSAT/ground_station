cout << RowVectorXi::Zero(4) << endl;
cout << VectorXf::Zero(2) << endl;
