cpp-netlib-cpp-netlib-0.9.4_xcode462_universal
==============================================

Patch files to enable you to compile universal binary libraries with gcc under xcode 4.6.2.<br/>

### development environment:

o MacOS X 10.7.5<br/>
o Xcode 4.6.2<br/>
o clang = Apple LLVM version 4.2 (clang-425.0.28) (based on LLVM 3.2svn)<br/>
o gcc = i686-apple-darwin11-llvm-gcc-4.2 (GCC) 4.2.1 (Based on Apple Inc. build 5658) (LLVM build 2336.11.00)<br/>
o boost_1_53_0<br/>



### apply a patch
### from http://github.com/toolbits/cpp-netlib-cpp-netlib-0.9.4_xcode462_universal
mv [document.h] cpp-netlib-cpp-netlib-0.9.4/.

cd cpp-netlib-cpp-netlib-0.9.4

mv document.h libs/network/example/twitter/rapidjson/.



### cpp-netlib with gcc
sudo rm -rf /usr/local/cpp-netlib_gcc

BOOST_INCLUDEDIR=/usr/local/boost_gcc/include; export BOOST_INCLUDEDIR<br/>
BOOST_LIBRARYDIR=/usr/local/boost_gcc/lib/a; export BOOST_LIBRARYDIR<br/>

cmake -DCMAKE_BUILD_TYPE=Release -DCMAKE_C_FLAGS="-arch i386 -arch x86_64" -DCMAKE_CXX_FLAGS="-arch i386 -arch x86_64" -DCMAKE_C_COMPILER=gcc -DCMAKE_CXX_COMPILER=g++ .<br/>
make<br/>

sudo mkdir -p /usr/local/cpp-netlib_gcc/include<br/>
sudo mkdir -p /usr/local/cpp-netlib_gcc/lib/a<br/>
sudo cp -R boost /usr/local/cpp-netlib_gcc/include/.<br/>
sudo cp libs/network/src/*.a /usr/local/cpp-netlib_gcc/lib/a/.<br/>
