cpp-netlib-0.11.0-final_xcode510_universal
==========================================

Patch files to enable you to compile universal binary (32bits + 64bits) libraries with clang under xcode 5.1.0.<br/>

### development environment:

o MacOS X 10.9.2<br/>
o Xcode 5.1.0<br/>
o clang = Apple LLVM version 5.1 (clang-503.0.38) (based on LLVM 3.4svn)<br/>
o boost_1_55_0<br/>



### apply patches
### from http://github.com/toolbits/cpp-netlib-0.11.0-final_xcode510_universal
mv [_CMakeLists.txt] cpp-netlib-0.11.0-final/.

cd cpp-netlib-0.11.0-final

mv _CMakeLists.txt libs/mime/test/CMakeLists.txt



### cpp-netlib with clang
sudo rm -rf /usr/local/cpp-netlib_clang

BOOST_INCLUDEDIR=/usr/local/boost_clang/include; export BOOST_INCLUDEDIR<br/>
BOOST_LIBRARYDIR=/usr/local/boost_clang/lib/a; export BOOST_LIBRARYDIR<br/>

cmake -DCMAKE_BUILD_TYPE=Release -DCMAKE_C_FLAGS="-arch i386 -arch x86_64" -DCMAKE_CXX_FLAGS="-arch i386 -arch x86_64" -DCMAKE_C_COMPILER=clang -DCMAKE_CXX_COMPILER=clang++ .<br/>
make<br/>

sudo mkdir -p /usr/local/cpp-netlib_clang/include<br/>
sudo mkdir -p /usr/local/cpp-netlib_clang/lib/a<br/>
sudo cp -R boost /usr/local/cpp-netlib_clang/include/.<br/>
sudo cp libs/network/src/*.a /usr/local/cpp-netlib_clang/lib/a/.<br/>
